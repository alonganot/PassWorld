# PassWorld

Access your passwords anytime!

version: 1.1.0
Patch notes:
- Added tooltips describing all buttons.
- Added "Edit passwords" tab.
- Made the id of each password unique.
- Changed background image and logo.
