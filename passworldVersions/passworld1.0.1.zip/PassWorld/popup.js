const key = "Capibara2019!";

const defaultPassArray = [
  {
    id: 1,
    wn: "Your list is empty!",
    un: "Add a username!",
    p: CryptoJS.AES.encrypt("Add a password!", key).toString(),
    link: "http://www.google.com",
  },
];

if (
  localStorage.getItem("pws") === null ||
  localStorage.getItem("pws").length === 1
) {
  localStorage.setItem("pws", JSON.stringify(defaultPassArray));
}

let passwordArray = JSON.parse(localStorage.getItem("pws"));

document.addEventListener("DOMContentLoaded", () => {
  initTable(passwordArray);

  document.getElementById("button-addon2").addEventListener("click", () => {
    addPass();
  });

  const searchBar = document.getElementById("searchBar");
  searchBar.addEventListener("input", () => {
    updateTable(searchBar.value);
  });
});

const initTable = (currArray) => {
  document.getElementById("mainTableBody").innerHTML = "";
  currArray.forEach((pass, index) => {
    const row = document.createElement("tr");
    const tableIndex = document.createElement("th");
    tableIndex.innerText = index + 1;

    const currSite = document.createElement("td");
    currSite.innerText = pass.wn;

    const buttons = document.createElement("td");
    buttons.setAttribute("id", "buttons");

    const userButton = document.createElement("button");
    userButton.setAttribute("type", "button");
    userButton.classList.add("btn");
    userButton.classList.add("btn-outline-primary");
    userButton.setAttribute("id", `user${index}`);

    const copyButton = document.createElement("button");
    copyButton.setAttribute("type", "button");
    copyButton.classList.add("btn");
    copyButton.classList.add("btn-outline-primary");
    copyButton.setAttribute("id", `button${index}`);

    const linkButton = document.createElement("button");
    linkButton.setAttribute("type", "button");
    linkButton.classList.add("btn");
    linkButton.classList.add("btn-outline-primary");
    linkButton.setAttribute("id", `link${index}`);

    const deleteButton = document.createElement("button");
    deleteButton.setAttribute("type", "button");
    deleteButton.classList.add("btn");
    deleteButton.classList.add("btn-outline-danger");
    deleteButton.setAttribute("id", `delete${index}`);

    const userIcon = document.createElement("i");
    userIcon.classList.add("fa");
    userIcon.classList.add("fa-user");
    userIcon.classList.add("fa-2x");

    const copyIcon = document.createElement("i");
    copyIcon.classList.add("fa");
    copyIcon.classList.add("fa-key");
    copyIcon.classList.add("fa-2x");

    const linkIcon = document.createElement("i");
    linkIcon.classList.add("fa");
    linkIcon.classList.add("fa-link");
    linkIcon.classList.add("fa-2x");

    const deleteIcon = document.createElement("i");
    deleteIcon.classList.add("fa");
    deleteIcon.classList.add("fa-trash");
    deleteIcon.classList.add("fa-2x");

    userButton.appendChild(userIcon);
    copyButton.appendChild(copyIcon);
    linkButton.appendChild(linkIcon);
    deleteButton.appendChild(deleteIcon);

    userButton.addEventListener("click", () => {
      copyUser(pass.id);
    });

    copyButton.addEventListener("click", () => {
      copyPassword(pass.id);
    });

    linkButton.addEventListener("click", () => {
      linkToPage(pass.link);
    });

    deleteButton.addEventListener("click", () => {
      deletePass(pass.id);
    });

    buttons.appendChild(userButton);
    buttons.appendChild(copyButton);
    buttons.appendChild(linkButton);
    buttons.appendChild(deleteButton);

    row.appendChild(tableIndex);
    row.appendChild(currSite);
    row.appendChild(buttons);

    document.getElementById("mainTableBody").appendChild(row);
  });
};

const updateTable = (input) => {
  const filteredArray = passwordArray.filter((pass) =>
    pass.wn.toLowerCase().includes(input.toLowerCase())
  );
  initTable(filteredArray);
};

const addPass = () => {
  if (JSON.parse(localStorage.getItem("pws"))[0].wn === "Your list is empty!") {
    console.log("firstpass");
    passwordArray = [];
  }

  const newPass = {
    id: passwordArray.length + 1,
    wn: `${document.getElementById("newPassSite").value}`,
    un: `${document.getElementById("newPassUser").value}`,
    p: CryptoJS.AES.encrypt(
      document.getElementById("newPassPass").value,
      key
    ).toString(),
    link: `${document.getElementById("newPassLink").value}`,
  };

  passwordArray.push(newPass);
  localStorage.setItem("pws", JSON.stringify(passwordArray));
  document.getElementById("newPassSite").value = "";
  document.getElementById("newPassPass").value = "";
  document.getElementById("newPassLink").value = "";
  initTable(passwordArray);
};

const copyUser = (index) => {
  const username = JSON.parse(localStorage.getItem("pws")).find((pass) => pass.id === index).un;

  navigator.clipboard.writeText(username).then(
    () => {
      console.log("Async: Copying to clipboard was successful!");
    },
    (err) => {
      console.error("Async: Could not copy text: ", err);
    }
  );
};

const copyPassword = (index) => {
  const decrypted = CryptoJS.AES.decrypt(
    JSON.parse(localStorage.getItem("pws")).find((pass) => pass.id === index).p,
    key
  );
  const actualPass = decrypted.toString(CryptoJS.enc.Utf8);

  navigator.clipboard.writeText(actualPass).then(
    () => {
      console.log("Async: Copying to clipboard was successful!");
    },
    (err) => {
      console.error("Async: Could not copy text: ", err);
    }
  );
};

const linkToPage = (link) => {
  window.open(link);
};

const deletePass = (id) => {
  passwordArray = passwordArray.filter((pass) => pass.id !== id);
  if (passwordArray.length === 0) {
    localStorage.setItem("pws", JSON.stringify(defaultPassArray));
    initTable(defaultPassArray);
  } else {
    localStorage.setItem("pws", JSON.stringify(passwordArray));
    initTable(passwordArray);
  }
};
