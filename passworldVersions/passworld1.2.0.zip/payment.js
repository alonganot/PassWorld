paypal
  .Buttons({
    style: {
      layout: "horizontal",
      shape: "pill",
    },
    createOrder: function (data, actions) {
      return actions.order.create({
        purchase_units: [
          {
            description: "PassWorld GOLD membership",
            amount: {
              value: "2.99",
            },
          },
        ],
      });
    },
    onApprove: function (data, actions) {
      return actions.order.capture().then((details) => {
        localStorage.setItem('ul', 'gold');
        window.open("golduser.html");
      });
    },
    onCancel: function (data) {
      alertify.error("You have canceled your order. Try again!");
    },
  })
  .render("#paypal-gold-button");

paypal
  .Buttons({
    style: {
      layout: "horizontal",
      color: "blue",
      shape: "pill",
    },
    createOrder: function (data, actions) {
      return actions.order.create({
        purchase_units: [
          {
            description: "PassWorld PLATINUM membership",
            amount: {
              value: "4.99",
            },
          },
        ],
      });
    },
    onApprove: function (data, actions) {
      return actions.order.capture().then((details) => {
        localStorage.setItem('ul', 'platinum');
        window.open("platinumuser.html");
      });
    },
    onCancel: function (data) {
      alertify.error("You have canceled your order. Try again!");
    },
  })
  .render("#paypal-platinum-button");
